# Compiling

Set the location of the Oracle Java bin directory in $JAVA_LOC in path.env
Optionally set the output folder in path.env

```
./compile.sh
```

# Run

After compiling:

```
./run.sh
```

source path.env

cd $OUT_LOC
$JAVA_LOC/java -classpath ./src sample.Main
